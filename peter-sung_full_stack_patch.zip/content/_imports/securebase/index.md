---
title: "Securebase"
description: ""
slug: "index"
sourceURL: "https://securebase.cc/"
lastFetched: "2025-11-21T07:36:24.836Z"
---

![](./images/67135b512f98d2b03a39dba2_logo-color.png)

[

# Meet  
Dr. Sung

![](./images/67134985858863c516c2d5a5_profile.png)](/about)[

# I speak _to_ leaders and _into_ their lives.  
  
It all starts with self-awareness.

# Get in Touch

](/contact)[

# Speaking

![](./images/66efb23f27d0018866656933_speech-line-art-01.svg)](/speaking)[

# Assessements

![](./images/6715d1a3656c123e0f32c055_speech-line-art-02.svg)](/assessments)[

# Coaching

![](./images/6715d1bc97866e3c25b68dfa_speech-line-art-03.svg)](/coaching)
